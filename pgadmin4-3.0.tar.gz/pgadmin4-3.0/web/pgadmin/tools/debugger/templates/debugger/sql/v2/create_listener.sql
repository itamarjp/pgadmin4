{### Create listener for debugging ###}
SELECT * from pldbg_create_listener()
