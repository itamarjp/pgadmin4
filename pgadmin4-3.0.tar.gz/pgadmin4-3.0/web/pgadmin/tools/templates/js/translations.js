define(function () {
  return {{ translations|tojson }};
});
