/*Copyright � 2017/*
SELECT 1;