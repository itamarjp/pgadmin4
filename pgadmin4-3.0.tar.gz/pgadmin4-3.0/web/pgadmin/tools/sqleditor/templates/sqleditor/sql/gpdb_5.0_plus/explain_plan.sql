EXPLAIN
{% if analyze %}
 ANALYZE
{% endif %}
 {{ sql }}
