define('bundled_browser',[
  'pgadmin.browser',
  'sources/browser/index',
], function(pgBrowser) {
  pgBrowser.init();
});
